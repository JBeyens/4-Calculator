package controller;


/**
 * 	@Author Ben Vandevorst & Jef Beyens
	@Datum 09/10/2017
	@Project Calculator
	@Doel Main(); => start controller
 */

public class CalculatorRunner {

	public static void main(String[] args) {
		CalculatorController controller = new CalculatorController();
		controller.startController();
	}

}
